// Roblox Wiki — dados de exemplo e interações da página.
const articles = [
  { id: "blox-fruits", title: "Blox Fruits", category: "Jogos", date: "JOGO", symbol: "果", colors: ["#6549d8", "#32266f"], description: "Uma experiência de aventura inspirada em anime, com exploração, habilidades e progressão.", body: "Blox Fruits é uma experiência de aventura dentro do Roblox. Os jogadores exploram ilhas, completam missões e desbloqueiam habilidades. Esta página é um resumo introdutório; confirme detalhes de atualizações em fontes oficiais do jogo." },
  { id: "brookhaven", title: "Brookhaven RP", category: "Jogos", date: "ROLEPLAY", symbol: "⌂", colors: ["#319d9a", "#164c64"], description: "Uma experiência social de interpretação de papéis, casas, veículos e exploração da cidade.", body: "Brookhaven RP é uma experiência social focada em roleplay. Os jogadores podem explorar a cidade e inventar histórias com outras pessoas. Respeite as regras do jogo e não compartilhe informações pessoais." },
  { id: "pet-simulator", title: "Pet Simulator", category: "Jogos", date: "COLEÇÃO", symbol: "♢", colors: ["#e5a23f", "#8d4c2b"], description: "Jogos de coleção de mascotes, exploração e desbloqueio de novas áreas.", body: "Pet Simulator é o nome associado a experiências de coleção de mascotes no Roblox. Mecânicas, eventos e itens podem variar entre versões. Confira a página oficial da experiência para informações atuais." },
  { id: "adopt-me", title: "Adopt Me!", category: "Jogos", date: "SOCIAL", symbol: "♡", colors: ["#e77caa", "#7d3d9a"], description: "Uma experiência social com mascotes, casas e atividades para explorar com amigos.", body: "Adopt Me! é uma experiência social popular que inclui mascotes, casas e atividades. Tenha cuidado com trocas: confira todos os itens antes de confirmar e nunca compartilhe sua senha." },
  { id: "iniciante", title: "Guia para iniciantes", category: "Guias", date: "GUIA", symbol: "➜", colors: ["#3d9dba", "#234d85"], description: "Dicas para encontrar experiências, entender os controles e personalizar seu avatar.", body: "Comece explorando experiências que combinem com seus interesses. Leia as instruções dentro do jogo, aprenda os controles e ajuste as configurações de privacidade. Nunca informe sua senha ou códigos de acesso a outras pessoas." },
  { id: "avatar", title: "Personalização do avatar", category: "Guias", date: "AVATAR", symbol: "♙", colors: ["#8a79f0", "#423b91"], description: "Conheça as opções para personalizar roupas, acessórios e aparência do seu avatar.", body: "O avatar pode ser personalizado com roupas, acessórios e diferentes itens disponíveis na plataforma. Alguns itens custam Robux; confira o preço e o item correto antes de comprar." },
  { id: "seguranca", title: "Segurança da conta", category: "Dicas", date: "DICAS", symbol: "⌑", colors: ["#42b99c", "#17665f"], description: "Práticas importantes para proteger sua conta e evitar golpes e links suspeitos.", body: "Use uma senha única, ative os recursos de segurança disponíveis e nunca compartilhe sua senha ou códigos de verificação. Desconfie de promessas de Robux grátis e links que imitam páginas oficiais." },
  { id: "npc", title: "O que é um NPC?", category: "Personagens", date: "PERSONAGEM", symbol: "◉", colors: ["#e47758", "#833b46"], description: "Entenda o que são personagens controlados pelo jogo e como eles podem funcionar.", body: "NPC significa personagem não controlado diretamente por um jogador. Em jogos, NPCs podem oferecer missões, conversar, vender itens ou participar de desafios. O comportamento depende de cada experiência." }
];

const grid = document.querySelector("#articleGrid");
const searchInput = document.querySelector("#searchInput");
const searchForm = document.querySelector("#searchForm");
const emptyState = document.querySelector("#emptyState");
const clearSearch = document.querySelector("#clearSearch");
const articleCount = document.querySelector("#articleCount");
const dialog = document.querySelector("#articleDialog");
const dialogContent = document.querySelector("#dialogContent");
let activeCategory = "Todos";
let query = "";

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

function renderArticles() {
  const normalized = query.trim().toLocaleLowerCase("pt-BR");
  const visible = articles.filter(article => {
    const matchesCategory = activeCategory === "Todos" || article.category === activeCategory;
    const searchable = `${article.title} ${article.category} ${article.description} ${article.body}`.toLocaleLowerCase("pt-BR");
    return matchesCategory && searchable.includes(normalized);
  });

  grid.innerHTML = visible.map(article => `
    <article class="article-card">
      <button class="article-open" data-open="${escapeHTML(article.id)}" aria-label="Ler artigo: ${escapeHTML(article.title)}">
        <div class="article-art" style="background:linear-gradient(135deg,${article.colors[0]},${article.colors[1]})">
          <span class="article-symbol">${escapeHTML(article.symbol)}</span>
        </div>
        <div class="article-body">
          <div class="article-meta"><span class="pill">${escapeHTML(article.category)}</span><span class="article-date">${escapeHTML(article.date)}</span></div>
          <h3>${escapeHTML(article.title)}</h3>
          <p>${escapeHTML(article.description)}</p>
          <span class="read-more">LER ARTIGO ↗</span>
        </div>
      </button>
    </article>
  `).join("");

  emptyState.hidden = visible.length !== 0;
  grid.hidden = visible.length === 0;
  articleCount.textContent = String(articles.length);
  clearSearch.hidden = !query && activeCategory === "Todos";
}

function setCategory(category) {
  activeCategory = category;
  document.querySelectorAll("[data-category].filter").forEach(button => {
    const active = button.dataset.category === category;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  renderArticles();
  document.querySelector("#explorar").scrollIntoView({ behavior: "smooth", block: "start" });
}

function openArticle(id) {
  const article = articles.find(item => item.id === id);
  if (!article) return;
  dialogContent.innerHTML = `
    <div class="dialog-art" style="background:linear-gradient(135deg,${article.colors[0]},${article.colors[1]})">${escapeHTML(article.symbol)}</div>
    <div class="dialog-copy">
      <span class="pill">${escapeHTML(article.category)}</span>
      <h2>${escapeHTML(article.title)}</h2>
      <p>${escapeHTML(article.body)}</p>
      <div class="dialog-note">Wiki comunitária: este artigo é um exemplo inicial. Ajude a manter as informações corretas e respeite as regras da plataforma.</div>
    </div>`;
  dialog.showModal();
}

searchForm.addEventListener("submit", event => {
  event.preventDefault();
  query = searchInput.value;
  renderArticles();
  document.querySelector("#explorar").scrollIntoView({ behavior: "smooth", block: "start" });
});

searchInput.addEventListener("input", () => {
  query = searchInput.value;
  renderArticles();
});

document.querySelector("#filters").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (button) setCategory(button.dataset.category);
});

document.querySelector(".category-tiles").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (button) setCategory(button.dataset.category);
});

document.querySelectorAll(".hint").forEach(button => {
  button.addEventListener("click", () => {
    searchInput.value = button.dataset.search;
    query = button.dataset.search;
    activeCategory = "Todos";
    document.querySelectorAll(".filter").forEach(item => item.classList.toggle("active", item.dataset.category === "Todos"));
    renderArticles();
    document.querySelector("#explorar").scrollIntoView({ behavior: "smooth", block: "start" });
  });
});

grid.addEventListener("click", event => {
  const button = event.target.closest("[data-open]");
  if (button) openArticle(button.dataset.open);
});

document.querySelector("#dialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});

function resetFilters() {
  query = "";
  searchInput.value = "";
  activeCategory = "Todos";
  document.querySelectorAll(".filter").forEach(item => item.classList.toggle("active", item.dataset.category === "Todos"));
  renderArticles();
}
document.querySelector("#clearSearch").addEventListener("click", resetFilters);
document.querySelector("#resetSearch").addEventListener("click", resetFilters);

const menuButton = document.querySelector("#menuButton");
const nav = document.querySelector(".topnav");
menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
}));

document.querySelector("#backTop").addEventListener("click", event => {
  event.preventDefault();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

renderArticles();
